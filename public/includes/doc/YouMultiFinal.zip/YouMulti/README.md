# YouMulti
 Basado en especificaciones provistas por la cátedra universitaria de la materia DAW de la facultad de ingenieria de la universidad San Juan Bosco sede Comodoro rivadavia, bajo el concepto de OOHDM se realiza un prototipo de sistema llamado YouMulti.
